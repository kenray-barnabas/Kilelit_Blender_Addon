import bpy
import webbrowser

def openkbspaceportals():
    spaceportals = "https://www.kenraysspaceportals.space/"
    webbrowser.open(spaceportals)

def openkbportfolio():
    portfolio = "https://kenraybarnabas.art/"
    webbrowser.open(portfolio)


def register():
    pass

def unregister():
    pass
